import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import os
from matplotlib.ticker import MaxNLocator

# 参数设定
phases = ["Encrypt", "Trapdoor", "Search", "Decrypt", "Insert", "Delete"]
keywords = [1000, 2000, 3000, 4000, 5000]
edms_data = {phase: [] for phase in phases}
eumar_data = {phase: [] for phase in phases}

# 创建输出目录
output_dir = "D:/wp123/Code/python/EUMAR/EDMS/doc/data/img"
os.makedirs(output_dir, exist_ok=True)

# 读取并组织数据
for kw in keywords:
    edms_file = f"D:/wp123/Code/python/EUMAR/EDMS/doc/data/test/EDMS_kw_{kw}.csv"
    eumar_file = f"D:/wp123/Code/python/EUMAR/EDMS/doc/data/test/EMUAR_kw_{kw}.csv"

    if os.path.exists(edms_file):
        df_edms = pd.read_csv(edms_file)
        df_edms = df_edms.set_index("Stage")["Time"]
        for phase in phases:
            edms_data[phase].append(df_edms.get(phase, float('nan')))
    else:
        print(f"Missing file: {edms_file}")
        for phase in phases:
            edms_data[phase].append(float('nan'))

    if os.path.exists(eumar_file):
        df_eumar = pd.read_csv(eumar_file)
        df_eumar = df_eumar.set_index("Stage")["Time"]
        for phase in phases:
            eumar_data[phase].append(df_eumar.get(phase, float('nan')))
    else:
        print(f"Missing file: {eumar_file}")
        for phase in phases:
            eumar_data[phase].append(float('nan'))

from matplotlib.ticker import FormatStrFormatter

for phase in phases:
    edms_y = edms_data[phase]
    eumar_y = eumar_data[phase]

    if len(edms_y) != len(keywords) or len(eumar_y) != len(keywords):
        print(f"Skipping {phase} due to data length mismatch.")
        continue

    # 单位换算：除 Encrypt 外，其它阶段结果统一乘以 1000
    if phase != "Encrypt":
        edms_y = [v * 1000 if not np.isnan(v) else v for v in edms_y]
        eumar_y = [v * 1000 if not np.isnan(v) else v for v in eumar_y]
        ylabel = f'{phase} Cost (×10⁻³ ms)'
    else:
        ylabel = f'{phase} Cost (ms)'

    fig, ax = plt.subplots(figsize=(3.5, 2.5), dpi=300)

    ax.plot(keywords, edms_y, marker='o', markersize=4, linewidth=1.2, label='EDMS')
    ax.plot(keywords, eumar_y, marker='^', markersize=4, linewidth=1.2, label='Ours')

    ax.set_xlabel('Number of Keywords')
    ax.set_ylabel(ylabel)

    ax.set_xlim(min(keywords), max(keywords))
    ax.set_xticks(keywords)

    ymin = min(min(edms_y), min(eumar_y))
    ymax = max(max(edms_y), max(eumar_y))
    ymargin = (ymax - ymin) * 0.05 if ymax != ymin else 1.0
    ax.set_ylim(ymin - ymargin, ymax + ymargin)

    # ✅ 添加不可见点触发上边框渲染
    ax.plot(keywords[-1], ymax + ymargin * 0.02, alpha=0)

    ax.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))
    yticks = np.linspace(ax.get_ylim()[0], ax.get_ylim()[1], 6)
    ax.set_yticks(yticks)

    # ✅ 显示所有边框（包括上边框），设置统一样式
    for spine in ax.spines.values():
        spine.set_visible(True)
        spine.set_linewidth(0.8)
        spine.set_edgecolor('black')

    # ✅ 微调边距
    fig.subplots_adjust(left=0.34, bottom=0.18, right=0.97, top=0.96)

    # ✅ 防止横坐标裁剪
    for label in ax.get_xticklabels():
        label.set_horizontalalignment('center')
    ax.tick_params(axis='x', pad=1)

    ax.margins(0)
    ax.legend(loc='upper right', frameon=False)
    ax.grid(True, linestyle='--', linewidth=0.5)

    # ✅ 保存三种格式，确保标签完整
    base_path = os.path.join(output_dir, f"{phase.lower()}_kw")
    plt.savefig(base_path + ".eps", format='eps', bbox_inches='tight')
    # plt.savefig(base_path + ".pdf", format='pdf', bbox_inches='tight')
    plt.savefig(base_path + ".png", format='png', dpi=300, bbox_inches='tight')

    plt.close()

