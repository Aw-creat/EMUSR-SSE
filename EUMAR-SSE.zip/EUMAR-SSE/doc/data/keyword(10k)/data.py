import pandas as pd
import numpy as np
import os


def add_rand_column(input_csv: str, output_csv: str, column_index: int = 4, new_column_name: str = 'rand1'):
    """
    读取CSV文件，基于指定列生成对应行数的随机数列，并添加为新列。

    :param input_csv: 输入CSV文件路径
    :param output_csv: 输出CSV文件路径
    :param column_index: 目标列的索引（默认第E列 = 4）
    :param new_column_name: 新生成列的名称
    """
    if not os.path.exists(input_csv):
        raise FileNotFoundError(f"文件未找到：{input_csv}")

    df = pd.read_csv(input_csv)

    if df.shape[1] <= column_index:
        raise ValueError(f"CSV文件没有足够的列（需要至少 {column_index + 1} 列）")

    # 生成随机整数列
    df[new_column_name] = np.random.randint(1, 5001, size=len(df))

    # 保存新文件
    df.to_csv(output_csv, index=False, encoding='utf-8')
    print(f"文件已保存：{output_csv}")


if __name__ == "__main__":
    # 示例路径（根据你的文件修改）
    input_file = "D:\wp123\Code\python\EUMAR\EDMS\doc\data\keyword(10k)\kw-3000.csv"
    output_file = "D:\wp123\Code\python\EUMAR\EDMS\doc\data\keyword(10k)\kw-5000.csv"

    add_rand_column(input_file, output_file)
