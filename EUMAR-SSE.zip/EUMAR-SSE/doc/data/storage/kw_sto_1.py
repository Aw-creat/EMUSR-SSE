import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import os
from matplotlib.ticker import FormatStrFormatter

# 设置参数
keywords = [1000, 2000, 3000, 4000, 5000]
metrics = [
    'EncryptedDataSize(Bytes)',
    'SecretKeySize(Bytes)',
    'IndexSize(Bytes)',
    'TrapdoorSize(Bytes)'
]
metric_labels = [
    'Ciphertext Size',
    'Private Key Size',
    'Index Size',
    'Trapdoor Size'
]

# 初始化数据结构
edms_data = {metric: [] for metric in metrics}
eumar_data = {metric: [] for metric in metrics}

# 设置路径
base_dir = "D:\wp123\Code\python\EUMAR\EDMS\doc\data\storage"  # 当前脚本所在目录
output_dir = os.path.join(base_dir, "output_storage_figs")
os.makedirs(output_dir, exist_ok=True)

# 读取CSV并填充数据（转为MB）
for kw in keywords:
    edms_file = os.path.join(base_dir, f"EDMS_sto_{kw}.csv")
    eumar_file = os.path.join(base_dir, f"EUMAR_sto_{kw}.csv")

    for metric in metrics:
        if os.path.exists(edms_file):
            df_edms = pd.read_csv(edms_file)
            edms_data[metric].append(df_edms[metric].values[0] / 1024)  # 字节转KB
        else:
            edms_data[metric].append(np.nan)

        if os.path.exists(eumar_file):
            df_eumar = pd.read_csv(eumar_file)
            eumar_data[metric].append(df_eumar[metric].values[0] / 1024)  # 字节转KB
        else:
            eumar_data[metric].append(np.nan)

# 绘图
for i, metric in enumerate(metrics):
    fig, ax = plt.subplots(figsize=(3.5, 2.5), dpi=300)

    edms_y = edms_data[metric]
    eumar_y = eumar_data[metric]

    ax.plot(keywords, edms_y, marker='o', markersize=4, linewidth=1.2, label='EDMS')
    ax.plot(keywords, eumar_y, marker='^', markersize=4, linewidth=1.2, label='Ours')

    ax.set_xlabel('Number of Keywords')
    ax.set_ylabel(f'{metric_labels[i]} (KB)')

    ax.set_xlim(min(keywords), max(keywords))
    ax.set_xticks(keywords)

    edms_y = edms_data[metric]
    eumar_y = eumar_data[metric]

    # ✅ NaN检查，避免画图时出错
    edms_clean = [v for v in edms_y if not np.isnan(v)]
    eumar_clean = [v for v in eumar_y if not np.isnan(v)]

    if not edms_clean or not eumar_clean:
        print(f"⚠️ Skipping {metric_labels[i]} due to missing data.")
        continue

    ymin = min(min(edms_clean), min(eumar_clean))
    ymax = max(max(edms_clean), max(eumar_clean))
    ymargin = (ymax - ymin) * 0.1 if ymax != ymin else 1.0
    ax.set_ylim(int(ymin - ymargin), int(ymax + ymargin) + 1)

    ax.yaxis.set_major_formatter(FormatStrFormatter('%.0f'))
    ax.set_yticks(np.linspace(ax.get_ylim()[0], ax.get_ylim()[1], 5))

    for spine in ax.spines.values():
        spine.set_visible(True)
        spine.set_linewidth(0.8)
        spine.set_edgecolor('black')

    fig.subplots_adjust(left=0.34, bottom=0.18, right=0.97, top=0.96)

    for label in ax.get_xticklabels():
        label.set_horizontalalignment('center')
    ax.tick_params(axis='x', pad=1)

    ax.margins(0)
    ax.legend(loc='upper right', frameon=False)
    ax.grid(True, linestyle='--', linewidth=0.5)

    save_path = os.path.join(output_dir, f"{metric.replace(' ', '_').lower()}_kw.png")
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.close()

print(f"✅ 图像已保存至: {output_dir}")
